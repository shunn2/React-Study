module.exports = {
  presets: ['babel-preset-react-app'],
}
